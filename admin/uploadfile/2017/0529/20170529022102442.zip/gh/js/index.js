/**
 * Created by apple on 16/12/2.
 */

$(function () {


    $("#check-out").on("click",function () {
        console.log(123);
        var unitName = $(".unitName").val();//公司名
        var account = $(".account").val();//账号
        var currency = $(".currency").val();//币种
        var startDate = $(".startDate").val();//起始日期
        var endDate = $(".endDate").val();//结束日期
        var minMoney = $(".minMoney").val();//最小值
        var maxMoney = $(".maxMoney").val();//最大值
        var otherAccount = $(".otherAccount").val();//对方帐号
        var tradeDirection = $(".tradeDirection").val();//交易方向

        // console.log("unitName",unitName);
        // console.log("account",account);
        // console.log("currency",currency);
        // console.log("startDate",startDate);
        // console.log("endDate",endDate);
        // console.log("minMoney",minMoney);
        // console.log("maxMoney",maxMoney);
        // console.log("otherAccount",otherAccount);
        // console.log("tradeDirection",tradeDirection);

        $.ajax({
            url:"http://trade.applinzi.com/query.php?unitName="+"&startDate="+startDate+"&endDate="+endDate,
            type:"GET",
            beforeSend:function () {

                var loading = new Image();
                loading.src="images/loading.gif";
                $("#data-box").html(loading);
                $("#detail").show();

            },
            success:function (res) {
                console.log("res",res);

                var header = '<table id=test border="0" cellspacing="1" bgcolor="#fff">'
                header+='<thead id=test-head>';
                header+='<tr>'
                header+='<td>入账日期</td>'
                header+='<td>入账时间</td>'
                header+='<td>借贷标志</td>'
                header+='<td>发生额（交易金额）</td>'
                header+='<td>凭证号</td>'
                header+='<td>对方单位名称</td>'
                header+='<td>对方账号</td>'
                header+='<td>余额</td>'
                header+='<td>摘要</td>'
                header+='<td>选择回单</td>'
                header+='<td>操作</td>'
                header+='<td>详细信息</td>'
                header+='<td>缴款书明细</td>'

                header+='</tr>'
                header+='</thead>'


                header+='<tbody >';



                var footer = '<tr>'
                footer += '<td height=18 colSpan=9 align=right></td>'
                footer += '<td height=18 align=middle>全选<input  type=checkbox ></td>'
                footer += '<td height=18 colSpan=3 align=middle><A href="javascript:batchbill()">打印已选回单</A>&nbsp;<A title=只要将电子回单存入云回单箱，就可以永久保存该电子回单 href="javascript:batchbill_cloud();">存入云回单箱</A>&nbsp;<A href="javascript:batchbilldown()">下载已选回单信息</A> <SELECT id=downloadebilllisttype name=downloadebilllisttype> <OPTION selected value=1>.txt</OPTION> <OPTION value=2>.xls</OPTION></SELECT> </td>'
                footer += '</tr>'
                footer += '</tbody>'

                footer += '</table>';

                var html = '';

                for (var i = 0; i<res.length;i++){
                    html += create(res[i]);
                }

                function create(data) {
                    var newhtml = '<tr >';
                    newhtml+='<td  >'+data.trade_date+'</td>';
                    newhtml+='<td >&nbsp;</td>';
                    newhtml+='<td >贷</td>';
                    newhtml+='<td >'+data.trade_money+'</td>';
                    newhtml+='<td >&nbsp;</td>';
                    newhtml+='<td >'+data.other_unit_name+'</td>';
                    newhtml+='<td ><a href="">'+data.other_account+'</a></td>';
                    newhtml+='<td >'+data.balance+'</td>';
                    newhtml+='<td >'+data.description+'</td>';
                    newhtml+='<td >'+data.choose_back+'</td>';
                    newhtml+='<td ><input type=checkbox name=billcheck /></td>';
                    newhtml+='<td ><a href="/">回单</a> <a href="/">存入云回单箱</a></td>';
                    newhtml+='<td >&nbsp;</td>';

                    newhtml+=' </tr>';
                    return newhtml;
                }




                var box = $("#data-box").html(header+html+footer);


            }
        })
    })


    //退出登录


    $("#login-out").on("click",function () {

        //window.opener=null;window.open('','_self');window.close();
        window.location.href = "gh.html";

    })





    $("#submit").on("click",function () {
        window.open("account-check.html");
        //console.log(123);
        window.close();

    })


    $('.startDate').datetimepicker({
        language:  'zh-CN',
        format:"yyyy/mm/dd",
        weekStart: 1,
        todayBtn:  1,
        autoclose: 1,
        todayHighlight: 1,
        startView: 2,
        forceParse: 0,
        showMeridian: 1,
        minView: "month",
    });
    $('.endDate').datetimepicker({
        language:  'zh-CN',
        format:"yyyy/mm/dd",
        weekStart: 1,
        todayBtn:  1,
        autoclose: 1,
        todayHighlight: 1,
        startView: 2,
        minView: "month",
        forceParse: 0
    });

    
    
    $("#look-all").on("click",function () {

        var obj = {
            bz:"人民币",
            cb:"钞",
            zhsx:"一般结算户",
            khh:"工行",
            blye:"",//保留余额
            djye:"",//冻结余额
            zrye:"4,540,980.89",//昨日余额
            dqye:"4,540,980.89",//		当前余额
            kyye:"4,540,980.89",///	可用余额
            cxsj:new Date().getHours() +":" +new Date().getMinutes() +":" +new Date().getSeconds()


        }

        $("#bz").text(obj.bz);
        $("#cb").text(obj.cb);
        $("#zhsx").text(obj.zhsx);
        $("#khh").text(obj.khh);
        $("#blye").text(obj.blye);
        $("#djye").text(obj.djye);
        $("#zrye").text(obj.zrye);
        $("#dqye").text(obj.dqye);
        $("#kyye").text(obj.kyye);
        $("#cxsj").text(obj.cxsj);


        $(".blye").text(obj.blye);
        $(".djye").text(obj.djye);
        $(".zrye").text(obj.zrye);
        $(".dqye").text(obj.dqye);
        $(".kyye").text(obj.kyye);

        console.log(obj);
    })

})






