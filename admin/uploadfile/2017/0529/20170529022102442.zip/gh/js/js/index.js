/**
 * Created by apple on 16/12/2.
 */

$(function () {


    $("#check-out").on("click",function () {
        console.log(123);
        var unitName = $(".unitName").val();//公司名
        var account = $(".account").val();//账号
        var currency = $(".currency").val();//币种
        var startDate = $(".startDate").val();//起始日期
        var endDate = $(".endDate").val();//结束日期
        var minMoney = $(".minMoney").val();//最小值
        var maxMoney = $(".maxMoney").val();//最大值
        var otherAccount = $(".otherAccount").val();//对方帐号
        var tradeDirection = $(".tradeDirection").val();//交易方向

        // console.log("unitName",unitName);
        // console.log("account",account);
        // console.log("currency",currency);
        // console.log("startDate",startDate);
        // console.log("endDate",endDate);
        // console.log("minMoney",minMoney);
        // console.log("maxMoney",maxMoney);
        // console.log("otherAccount",otherAccount);
        // console.log("tradeDirection",tradeDirection);

        $.ajax({
            url:"http://trade.applinzi.com/query.php?unitName="+unitName+"&account="+account+"&currency="+currency+"&startDate="+startDate+"&endDate="+endDate+"&minMoney="+minMoney+"&maxMoney="+maxMoney+"&otherAccount="+otherAccount+"&tradeDirection="+tradeDirection,
            type:"GET",
            success:function (res) {
                console.log("res",res);

            }
        })
    })


    //退出登录


    $("#login-out").on("click",function () {

        //window.opener=null;window.open('','_self');window.close();
        window.location.href = "http://localhost/gh/gh.html";

    })
})




