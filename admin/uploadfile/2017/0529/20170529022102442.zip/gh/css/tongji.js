
 
/**��ȡ��ͳ����ҳ���ݲ���*/
function ar_get_clientInfo(key){
	var _arc = window._arc || [];
	for(i=0;i<_arc.length;i++) {
		if (_arc[i][0] == key) {
			return _arc[i][1];
		}
	}
	return "";
}

/**��ȡ��ͳ����ҳ���ݲ���*/
function ar_join_clientInfo(){
	var u = "";
	var _arc = window._arc || [];
	for(i=0;i<_arc.length;i++) {
		u += "&" + _arc[i][0] + "=" + _arc[i][1];
	}
	return u;
}
 
/**�����ɶ��ַ������б��룬�����Ϳ��������еļ�����϶�ȡ���ַ�����*/
function ar_encode(str)
{
	var e = "", i = 0;

	for(i=0;i<str.length;i++) {
		if(str.charCodeAt(i)>=0&&str.charCodeAt(i)<=255) {
			e = e + escape(str.charAt(i));
		}
		else {
			e = e + str.charAt(i);
		}
	}

	return e;
}


/**��Ļ�ֱ���*/
function ar_get_screen()
{
	var c = "";

	if (self.screen) {
		c = screen.width+"x"+screen.height;
	}

	return c;
}

/**��ɫ����*/
function ar_get_color()
{
	var c = ""; 

	if (self.screen) {
		c = screen.colorDepth+"-bit";
	}

	return c;
}

/**���ز���ϵͳ����*/
function ar_get_os(){
	var ua = navigator.userAgent.toLowerCase();
	var platform = navigator.platform.toLowerCase();
	var isWin = (platform == "win32")||(platform == "windows");
	var p = new Object();
	if(isWin){
		 p.Windows2000 = ua.indexOf("nt 5.0")> -1 || ua.indexOf("windows 2000")>-1;
		 p.WindowsXP = ua.indexOf("nt 5.1")>-1 || ua.indexOf("windows xp")>-1;
		 p.Windows2003 = ua.indexOf("nt 5.2")>-1 || ua.indexOf("windows 2003")>-1;
		 p.WindowsVista = ua.indexOf("nt 6.0")>-1 || ua.indexOf("windows vista")>-1;
		 p.Windows7 = ua.indexOf("nt 6.1")>-1 || ua.indexOf("windows 7")>-1;
		 p.Windows8 = ua.indexOf("nt 6.2")>-1 || ua.indexOf("windows 8")>-1;
		 p.Windows8v1 = ua.indexOf("nt 6.3")>-1 || ua.indexOf("windows 8")>-1;
		 p.Windows10 = ua.indexOf("nt 6.4")>-1 || ua.indexOf("nt 10.0")>-1 || ua.indexOf("windows 10.0")>-1;
		 for (var i in p){
			 if(p[i]){
				 	if(i=="Windows8v1"){
				 		i = "Windows8.1";
				 	}
				 	p = null;
					return(i);
			}
		 }
	}else{
		return "NotWindows";
	}
}

/**���ص�ǰ�����������*/
function ar_get_language()
{
	var l = "";
	var n = navigator;

	if (n.language) {
		l = n.language.toLowerCase();
	}
	else
	if (n.browserLanguage) {
		l = n.browserLanguage.toLowerCase();
	}

	return l;
}

/**�������������IE,Firefox*/
function ar_get_agent()
{
	var a = "";
	var n = navigator;

	if (n.userAgent) {
		a = n.userAgent;
	}

	return a;
}

/**�����ɷ���һ������ֵ����ֵָʾ������Ƿ�֧�ֲ�������Java*/
function ar_get_jvm_enabled()
{
	var j = "";
	var n = navigator;

	j = n.javaEnabled() ? 1 : 0;

	return j;
}

/**����������Ƿ�֧��(����)cookie */
function ar_get_cookie_enabled()
{
	var c = "";
	var n = navigator;
	c = n.cookieEnabled ? 1 : 0;

	return c;
}

/**���������Ƿ�֧��Flash����Flash���*/
function ar_get_flash_ver()
{
	var f="",n=navigator;

	if (n.plugins && n.plugins.length) {
		for (var ii=0;ii<n.plugins.length;ii++) {
			if (n.plugins[ii].name.indexOf('Shockwave Flash')!=-1) {
				f=n.plugins[ii].description.split('Shockwave Flash ')[1];
				break;
			}
		}
	}
	else
	if (window.ActiveXObject) {
		for (var ii=10;ii>=2;ii--) {
			try {
				var fl=eval("new ActiveXObject('ShockwaveFlash.ShockwaveFlash."+ii+"');");
				if (fl) {
					f=ii + '.0';
					break;
				}
			}
			 catch(e) {}
		}
	}
	return f;
} 

/**�������������Ϣ*/
function ar_get_app()
{
	var a = "";
	var n = navigator;

	if (n.appName) {
		a = n.appName;
	}
	return a; 
}
 
/**ƥ�䶥������*/
function ar_c_ctry_top_domain(str)
{
	var pattern = "/^aero$|^cat$|^coop$|^int$|^museum$|^pro$|^travel$|^xxx$|^com$|^net$|^gov$|^org$|^mil$|^edu$|^biz$|^info$|^name$|^ac$|^mil$|^co$|^ed$|^gv$|^nt$|^bj$|^hz$|^sh$|^tj$|^cq$|^he$|^nm$|^ln$|^jl$|^hl$|^js$|^zj$|^ah$|^hb$|^hn$|^gd$|^gx$|^hi$|^sc$|^gz$|^yn$|^xz$|^sn$|^gs$|^qh$|^nx$|^xj$|^tw$|^hk$|^mo$|^fj$|^ha$|^jx$|^sd$|^sx$/i";

	if(str.match(pattern)){ return 1; }

	return 0;
}

/**ƥ������*/
function ar_c_ctry_domain(str)
{
	var pattern = "/^ac$|^ad$|^ae$|^af$|^ag$|^ai$|^al$|^am$|^an$|^ao$|^aq$|^ar$|^as$|^at$|^au$|^aw$|^az$|^ba$|^bb$|^bd$|^be$|^bf$|^bg$|^bh$|^bi$|^bj$|^bm$|^bo$|^br$|^bs$|^bt$|^bv$|^bw$|^by$|^bz$|^ca$|^cc$|^cd$|^cf$|^cg$|^ch$|^ci$|^ck$|^cl$|^cm$|^cn$|^co$|^cr$|^cs$|^cu$|^cv$|^cx$|^cy$|^cz$|^de$|^dj$|^dk$|^dm$|^do$|^dz$|^ec$|^ee$|^eg$|^eh$|^er$|^es$|^et$|^eu$|^fi$|^fj$|^fk$|^fm$|^fo$|^fr$|^ly$|^hk$|^hm$|^hn$|^hr$|^ht$|^hu$|^id$|^ie$|^il$|^im$|^in$|^io$|^ir$|^is$|^it$|^je$|^jm$|^jo$|^jp$|^ke$|^kg$|^kh$|^ki$|^km$|^kn$|^kp$|^kr$|^kw$|^ky$|^kz$|^la$|^lb$|^lc$|^li$|^lk$|^lr$|^ls$|^lt$|^lu$|^lv$|^ly$|^ga$|^gb$|^gd$|^ge$|^gf$|^gg$|^gh$|^gi$|^gl$|^gm$|^gn$|^gp$|^gq$|^gr$|^gs$|^gt$|^gu$|^gw$|^gy$|^ma$|^mc$|^md$|^mg$|^mh$|^mk$|^ml$|^mm$|^mn$|^mo$|^mp$|^mq$|^mr$|^ms$|^mt$|^mu$|^mv$|^mw$|^mx$|^my$|^mz$|^na$|^nc$|^ne$|^nf$|^ng$|^ni$|^nl$|^no$|^np$|^nr$|^nu$|^nz$|^om$|^re$|^ro$|^ru$|^rw$|^pa$|^pe$|^pf$|^pg$|^ph$|^pk$|^pl$|^pm$|^pr$|^ps$|^pt$|^pw$|^py$|^qa$|^wf$|^ws$|^sa$|^sb$|^sc$|^sd$|^se$|^sg$|^sh$|^si$|^sj$|^sk$|^sl$|^sm$|^sn$|^so$|^sr$|^st$|^su$|^sv$|^sy$|^sz$|^tc$|^td$|^tf$|^th$|^tg$|^tj$|^tk$|^tm$|^tn$|^to$|^tp$|^tr$|^tt$|^tv$|^tw$|^tz$|^ua$|^ug$|^uk$|^um$|^us$|^uy$|^uz$|^va$|^vc$|^ve$|^vg$|^vi$|^vn$|^vu$|^ye$|^yt$|^yu$|^za$|^zm$|^zr$|^zw$/i";

	if(str.match(pattern)){ return 1; }

	return 0;
}

/**����������ַ*/
function ar_get_domain(host)
{
	var d=host.replace(/^www\./, "");

	var ss=d.split(".");
	var l=ss.length;

	if(l == 3){
		if(ar_c_ctry_top_domain(ss[1]) && ar_c_ctry_domain(ss[2])){
		}
		else{
			d = ss[1]+"."+ss[2];
		}
	}
	else if(l >= 3){

		var ip_pat = "^[0-9]*\.[0-9]*\.[0-9]*\.[0-9]*$";

		if(host.match(ip_pat)){
			return d;
		}

		if(ar_c_ctry_top_domain(ss[l-2]) && ar_c_ctry_domain(ss[l-1])) {
			d = ss[l-3]+"."+ss[l-2]+"."+ss[l-1];
		}
		else{
			d = ss[l-2]+"."+ss[l-1];
		}
	}
		
	return d;
}

/**����cookie��Ϣ*/
function ar_get_cookie(name)
{
	var mn=name+"=";
	var b,e;
	var co=document.cookie;

	if (mn=="=") {
		return co;
	}

	b=co.indexOf(mn);

	if (b < 0) {
		return "";
	}

	e=co.indexOf(";", b+name.length);

	if (e < 0) {
		return co.substring(b+name.length + 1);
	}
	else {
		return co.substring(b+name.length + 1, e);
	}
}

/**����cookie��Ϣ*/
function ar_set_cookie(name, val, cotp) 
{ 
	var date=new Date; 
	var year=date.getFullYear(); 
	var hour=date.getHours(); 

	var cookie="";

	if (cotp == 0) { 
		cookie=name+"="+val+";"; 
	} 
	else if (cotp == 1) { 
		year=year+10; 
		date.setYear(year); 
		cookie=name+"="+val+";expires="+date.toGMTString()+";"; 
	} 
	else if (cotp == 2) { 
		hour=hour+1; 
		date.setHours(hour); 
		cookie=name+"="+val+";expires="+date.toGMTString()+";"; 
	} 

	var d=ar_get_domain(document.domain);
	if(d != ""){
		cookie +="domain="+d+";";
	}
	cookie +="path="+"/;";

	document.cookie=cookie;
}

/**�ַ�����ת*/
function str_reverse(str) {
	var ln = str.length;
	var i=0;
	var temp="";
	for(i=ln-1; i>-1; i--) {
		if(str.charAt(i)==".")
			temp += "#";
		else
			temp += str.charAt(i);
	}

	return temp;
}

function ar_get_ss_id(str)
{
	len=str.indexOf("_");
	str=str.substring(len+1);
	len=str.indexOf("_");
	str=str.substring(len+1);
	return str;
}

function ar_get_ss_no(str) {
	len=str.indexOf("_");
	str=str.substring(0,len);
	return parseInt(str);
}

/**���ؿͻ���ʱ��*/
function ar_get_stm() 
{ 
	var date = new Date(); 
	var yy=date.getFullYear(); 
	var mm=date.getMonth(); 
	var dd=date.getDate(); 
	var hh=date.getHours(); 
	var ii=date.getMinutes(); 
	var ss=date.getSeconds(); 
	var i; 
	var tm=0; 
	for(i = 1970; i < yy; i++) { 
		if ((i % 4 == 0 && i % 100 != 0) || (i % 100 == 0 && i % 400 == 0)) { 
			tm=tm+31622400; 
		} 
		else { 
			tm=tm+31536000; 
		} 
	}
	mm=mm+1;
	
	for(i = 1; i < mm; i++) { 
		if (i == 1 || i == 3 || i == 5 || i == 7 || i == 8 || i == 10 || i == 12) { 
			tm=tm+2678400; 
		} 
		else { 
			if (i == 2) { 
				if ((yy % 4 == 0 && yy % 100 != 0) || (yy % 100 == 0 && yy % 400 == 0)) { 
					tm=tm+2505600; 
				} 
				else { 
					tm=tm+2419200; 
				} 
			} 
		 	else { 
				tm=tm+2592000; 
			} 
		} 
	}
	
	tm = tm +  (dd-1) * 86400; tm = tm +  hh * 3600; 
	tm = tm +  ii * 60; 
	tm = tm +  ss; 
	return tm; 
} 


function ar_get_ctm(str) {
	len=str.indexOf("_");
	str=str.substring(len+1);
	len=str.indexOf("_");
	str=str.substring(0,len);
	return parseInt(str, 10); 
}

/**����ָ��������������ִ�*/
function ar_get_random(n) {
	var str = "";
	for (var i = 0; i < n; i ++) {
		str += String(parseInt(Math.random() * 10));
	}
	return str;
}
var pvImageObj;
/* main function */
function ar_main(dest_path) {
	
	var unit_id     = "9999";//��վid
	var client_ip   = "124.160.136.205";
	//var dest_path   = "http://stat.analytics2.com/images/blank.gif?unit_id="+unit_id; 
	//var dest_path   = "http://localhost:8081/ebankc/images/logonew.gif?unit_id="+unit_id; 
	var expire_time = 1800; 
	var i;

	var host=document.location.host;
	var domain = ar_get_domain(host.toLocaleLowerCase());
	var hashval = 0;
	for (i=0; i< domain.length; i++){
		hashval += domain.charCodeAt(i);
	}

	var uv_str = ar_get_cookie("ar_stat_uv");
	var uv_id = "";
	var uv_new = 0;
	if (uv_str == ""){
		uv_new = 1;

		uv_id = ar_get_random(20);

		var value = uv_id+"|"+unit_id;
		
		ar_set_cookie("ar_stat_uv", value, 1);
	}
	else{
		var arr = uv_str.split("|");
		uv_id  = arr[0];
		var uids_str = arr[1];
		var uids = uids_str.split("@");
		var uid_num = uids.length;

		var bingo = 0;
		for(var pos=0,max=uids.length;pos<max;pos++) {
			var uid = uids[pos];
			if (uid == unit_id){
				bingo = 1;
				break;
			}
		}

		if (bingo == 0){
			uv_new = 1;

			if (uid_num >= 100){
				var value = uv_id+"|"+unit_id;
			}
			else{
				var value = uv_str+"@"+unit_id;
			}	
			
			ar_set_cookie("ar_stat_uv", value, 1);
		}
	}

	var ss_str = ar_get_cookie("ar_stat_ss"); 
	var ss_id = "";  //�漴��
	var ss_no = 0;   //session��Ч���ڷ���ҳ��Ĵ���
	if (ss_str == ""){
		ss_no = 0;
		ss_id = ar_get_random(10);
		value = ss_id+"_"+"0_"+ar_get_stm()+"_"+unit_id;
		ar_set_cookie("ar_stat_ss", value, 0); 
	} 
	else { 
		var arr = ss_str.split("|");
		var ss_num = arr.length;

		var bingo = 0;
		for(var pos=0,max=arr.length;pos<max;pos++) {
			var ss_info = arr[pos];
			var items = ss_info.split("_");

			var cookie_ss_id  = items[0];
			var cookie_ss_no  = parseInt(items[1]);
			var cookie_ss_stm = items[2];
			var cookie_ss_uid = items[3];

			if (cookie_ss_uid == unit_id){
				bingo = 1;

				if (ar_get_stm() - cookie_ss_stm > expire_time) { 
					ss_no = 0;
					ss_id = ar_get_random(10);
				} 
				else{
					ss_no = cookie_ss_no + 1;
					ss_id = cookie_ss_id;
				}

				value = ss_id+"_"+ss_no+"_"+ar_get_stm()+"_"+unit_id;

				arr[pos] = value;
				ss_str = arr.join("|");
				ar_set_cookie("ar_stat_ss", ss_str, 0); 

				break;
			}
		}

		if (bingo == 0)
		{
			ss_no = 0;
			ss_id = ar_get_random(10);
			value = ss_id+"_"+"0_"+ar_get_stm()+"_"+unit_id;

			if (ss_num >= 20){
				pos = parseInt(Math.random() * ss_num);
			}
			else{
				pos = ss_num;
			}

			arr[pos] = value;
			ss_str = arr.join("|");
			ar_set_cookie("ar_stat_ss", ss_str, 0); 
		}
	}
  
    //���ص�������ǰ��ҳ�ĳ�����������ҳ��URL
	var ref = document.referrer; 
	ref = ar_encode(String(ref)); 
	
	var refname = document.referrer.substring(document.referrer.lastIndexOf("/")+1);
	refname = ar_encode(String(refname)); 
	
	var url = document.URL; 
	url = ar_encode(String(url)); 
	
	var urlname = document.URL.substring(document.URL.lastIndexOf("/")+1);
	urlname = ar_encode(String(urlname)); 

	var title = document.title;
	//title = escape(String(title)); 
	title = ar_encode(title);//�����escape�������־title��ȡʱ�޷�������ԭ

	var charset = document.charset;
	charset = ar_encode(String(charset)); 

	var screen = ar_get_screen(); 
	screen = ar_encode(String(screen)); 

	var color =ar_get_color(); 
	color =ar_encode(String(color)); 

	var language = ar_get_language(); 
	language = ar_encode(String(language));
 
	var agent =ar_get_agent(); 
	agent =ar_encode(String(agent));

	var jvm_enabled =ar_get_jvm_enabled(); 
	jvm_enabled =ar_encode(String(jvm_enabled)); 

	var cookie_enabled =ar_get_cookie_enabled(); 
	cookie_enabled =ar_encode(String(cookie_enabled)); 

	var flash_ver = ar_get_flash_ver();
	flash_ver = ar_encode(String(flash_ver)); 

	var stat_uv = ss_id+"_"+ss_no+"_"+ar_get_stm();
	
	var os = ar_get_os();
	os = ar_encode(String(os));
	dest=dest_path+"?url="+url+"&urlname="+urlname+"&title="+title+"&chset="+charset+"&scr="+screen+"&col="+color+"&lg="+language+"&je="+jvm_enabled+"&ec="+cookie_enabled+"&fv="+flash_ver+"&cnv="+String(Math.random())+"&ref="+ref+"&refname="+refname+"&uagent="+agent+"&stat_ss="+uv_id+"&stat_uv="+stat_uv+"&os="+os;
    dest+=ar_join_clientInfo();
    if(undefined != top.pvurlAvailable && top.pvurlAvailable==0){
    	var timeout = 3000;
    	if(undefined != top.pvurlTimeout){
    		timeout = top.pvurlTimeout;
    	}
    	setTimeout("setPvurlStat()", timeout);
    }
    pvImageObj = new Image();
    pvImageObj.src = dest;
}

function setPvurlStat(){
	if(undefined != top.pvurlAvailable){
		if(pvImageObj.complete){
			top.pvurlAvailable = 1;
		}else{
			top.pvurlAvailable = -1;
		}
	}
}

function ar_sendpv(dest_path){
	if(undefined == top.pvurlAvailable){
		ar_main(dest_path);
	}else if(undefined != top.pvurlAvailable && top.pvurlAvailable != -1){
		ar_main(dest_path);
	}
}

function ar_send(dest_path){
	var unit_id     = "9999";//��վid
	var client_ip   = "124.160.136.205";
	//var dest_path   = "http://stat.analytics2.com/images/blank.gif?unit_id="+unit_id; 
	//var dest_path   = "http://localhost:8081/ebankc/images/logonew.gif?unit_id="+unit_id; 
	var expire_time = 1800; 
	var i;

	var host=document.location.host;
	var domain = ar_get_domain(host.toLocaleLowerCase());
	var hashval = 0;
	for (i=0; i< domain.length; i++){
		hashval += domain.charCodeAt(i);
	}

	var uv_str = ar_get_cookie("ar_stat_uv");
	var uv_id = "";
	var uv_new = 0;
	if (uv_str == ""){
		uv_new = 1;

		uv_id = ar_get_random(20);

		var value = uv_id+"|"+unit_id;
		
		ar_set_cookie("ar_stat_uv", value, 1);
	}
	else{
		var arr = uv_str.split("|");
		uv_id  = arr[0];
		var uids_str = arr[1];
		var uids = uids_str.split("@");
		var uid_num = uids.length;

		var bingo = 0;
		for(var pos=0,max=uids.length;pos<max;pos++) {
			var uid = uids[pos];
			if (uid == unit_id){
				bingo = 1;
				break;
			}
		}

		if (bingo == 0){
			uv_new = 1;

			if (uid_num >= 100){
				var value = uv_id+"|"+unit_id;
			}
			else{
				var value = uv_str+"@"+unit_id;
			}	
			
			ar_set_cookie("ar_stat_uv", value, 1);
		}
	}

	var ss_str = ar_get_cookie("ar_stat_ss"); 
	var ss_id = "";  //�漴��
	var ss_no = 0;   //session��Ч���ڷ���ҳ��Ĵ���
	if (ss_str == ""){
		ss_no = 0;
		ss_id = ar_get_random(10);
		value = ss_id+"_"+"0_"+ar_get_stm()+"_"+unit_id;
		ar_set_cookie("ar_stat_ss", value, 0); 
	} 
	else { 
		var arr = ss_str.split("|");
		var ss_num = arr.length;

		var bingo = 0;
		for(var pos=0,max=arr.length;pos<max;pos++) {
			var ss_info = arr[pos];
			var items = ss_info.split("_");

			var cookie_ss_id  = items[0];
			var cookie_ss_no  = parseInt(items[1]);
			var cookie_ss_stm = items[2];
			var cookie_ss_uid = items[3];

			if (cookie_ss_uid == unit_id){
				bingo = 1;

				if (ar_get_stm() - cookie_ss_stm > expire_time) { 
					ss_no = 0;
					ss_id = ar_get_random(10);
				} 
				else{
					ss_no = cookie_ss_no + 1;
					ss_id = cookie_ss_id;
				}

				value = ss_id+"_"+ss_no+"_"+ar_get_stm()+"_"+unit_id;

				arr[pos] = value;
				ss_str = arr.join("|");
				ar_set_cookie("ar_stat_ss", ss_str, 0); 

				break;
			}
		}

		if (bingo == 0)
		{
			ss_no = 0;
			ss_id = ar_get_random(10);
			value = ss_id+"_"+"0_"+ar_get_stm()+"_"+unit_id;

			if (ss_num >= 20){
				pos = parseInt(Math.random() * ss_num);
			}
			else{
				pos = ss_num;
			}

			arr[pos] = value;
			ss_str = arr.join("|");
			ar_set_cookie("ar_stat_ss", ss_str, 0); 
		}
	}
  
    //���ص�������ǰ��ҳ�ĳ�����������ҳ��URL
	var ref = document.referrer; 
	ref = ar_encode(String(ref)); 
	
	var refname = document.referrer.substring(document.referrer.lastIndexOf("/")+1);
	refname = ar_encode(String(refname)); 
	
	var url = document.URL; 
	url = ar_encode(String(url)); 
	
	var urlname = document.URL.substring(document.URL.lastIndexOf("/")+1);
	urlname = ar_encode(String(urlname)); 

	var title = document.title;
	//title = escape(String(title)); 
	title = ar_encode(title);//�����escape�������־title��ȡʱ�޷�������ԭ

	var charset = document.charset;
	charset = ar_encode(String(charset)); 

	var screen = ar_get_screen(); 
	screen = ar_encode(String(screen)); 

	var color =ar_get_color(); 
	color =ar_encode(String(color)); 

	var language = ar_get_language(); 
	language = ar_encode(String(language));
 
	var agent =ar_get_agent(); 
	agent =ar_encode(String(agent));

	var jvm_enabled =ar_get_jvm_enabled(); 
	jvm_enabled =ar_encode(String(jvm_enabled)); 

	var cookie_enabled =ar_get_cookie_enabled(); 
	cookie_enabled =ar_encode(String(cookie_enabled)); 

	var flash_ver = ar_get_flash_ver();
	flash_ver = ar_encode(String(flash_ver)); 

	var stat_uv = ss_id+"_"+ss_no+"_"+ar_get_stm();
	
	var os = ar_get_os();
	os = ar_encode(String(os));
	dest=dest_path+"?url="+url+"&urlname="+urlname+"&title="+title+"&chset="+charset+"&scr="+screen+"&col="+color+"&lg="+language+"&je="+jvm_enabled+"&ec="+cookie_enabled+"&fv="+flash_ver+"&cnv="+String(Math.random())+"&ref="+ref+"&refname="+refname+"&uagent="+agent+"&stat_ss="+uv_id+"&stat_uv="+stat_uv+"&os="+os;
    dest+=ar_join_clientInfo();
    var dom = document.createElement("img");
    dom.setAttribute("src",dest);
    dom.setAttribute("border","0");
    dom.setAttribute("width","1");
    dom.setAttribute("height","1");
    document.body.appendChild(dom);
}
//ar_main();
